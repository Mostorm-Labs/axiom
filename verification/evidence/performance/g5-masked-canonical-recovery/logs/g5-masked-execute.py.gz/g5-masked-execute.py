from pathlib import Path
import sys,json,gzip,time,re,subprocess,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'verification/runners/g5'));from bounded_worker import run
O=R/'out/g5-masked-final';O.mkdir(exist_ok=True)
def load(p):return json.loads(gzip.decompress(p.read_bytes()))if p.suffix=='.gz'else json.loads(p.read_text())
def emit(v):print(json.dumps(v),flush=True)
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
emit({'stage':'waiting-for-regressions'})
log=R/'out/g5-masked-full-ctest.log'
while'Total Test time'not in log.read_text(errors='replace')or not(R/'out/g5-masked-boundaries.log').exists():time.sleep(1)
s=log.read_text();names=sorted(re.findall(r'^\s*\d+ - (.*?) \(',s.split('The following tests FAILED:')[-1],re.M));total=int(re.search(r'/([0-9]+) Test',s).group(1));prior=load(R/'verification/evidence/performance/g5-erase-recovery/raw/native-comparison.json')['failed_names'];v={'passed':total-len(names),'total':total,'failed_names':names,'new_failed_names':sorted(set(names)-set(prior)),'resolved_names':sorted(set(prior)-set(names))};write(O/'native-comparison.json',v);emit({'stage':'regressions-complete','passed':v['passed'],'total':total,'new':v['new_failed_names']});assert not v['new_failed_names']
code=subprocess.check_output(['git','rev-parse','82291be6'],text=True).strip()
for side in ['on','off']:
 root=R/f'out/g5-masked-{side}/js';meta=load(root/'package.json');files=sorted(p for p in root.rglob('*')if p.is_file());assert len(files)==36 and list(meta['exports'])==['.']and not any(p.suffix in['.a','.h','.hpp']for p in files)
emit({'stage':'private-gpu-start'});w=run(['node','out/g5-masked-gpu.mjs','out/web-sampling/sdk/web',str(O/'gpu.json')],O/'gpu-worker',180,3072*1024);emit({'stage':'private-gpu-complete','worker':w});assert w['reason']=='completed'and w['cleanup_complete']
for name,side,dpr,blocking in [('candidate-on-dpr2','on',2,True),('candidate-off-dpr2','off',2,True),('candidate-on-dpr2-repeat','on',2,True),('candidate-on-dpr1','on',1,False),('candidate-on-dpr4','on',4,False)]:
 emit({'stage':'sequential-start','case':name});w=run(['node','verification/runners/g5/duplicated_erase_navigation.mjs',str(R/f'out/g5-masked-{side}/js'),str(O/name),str(dpr),'candidate'],O/(name+'-worker'),180,3072*1024);p=O/name/'observation.json.gz';b=load(p)if p.exists()else{};ok=w['cleanup_complete']and b.get('sourceStable')and b.get('artifactStable')and b.get('setup',{}).get('build',{}).get('sourceRevision')==code and b.get('setup',{}).get('build',{}).get('dirty')is False and b.get('status')in(['MEASURED']if blocking else['MEASURED','BLOCKED_ENDPOINT']);emit({'stage':'sequential-complete','case':name,'blocking':blocking,'ok':bool(ok),'status':b.get('status'),'timing':[p['timing']for p in b.get('phases',[])],'error':b.get('error')});assert ok,name
for name,command in [('dense',['node','verification/runners/g5/dense_erase.mjs','out/g5-masked-on/js',str(O/'dense'),'2','candidate']),('capacity',['node','verification/sdk_js/verify_partial_erase_capacity.mjs','out/g5-masked-off/js',str(O/'capacity.json'),'2']),('mixed',['node','verification/runners/g5/post_edit_navigation.mjs','out/g5-masked-on/js',str(O/'mixed'),'4']),('rejected-pixels',['node','out/g5-erase-reject-pixels.mjs','out/g5-masked-off/js',str(O/'rejected-pixels.json')])]:
 emit({'stage':'regression-start','case':name});w=run(command,O/(name+'-worker'),180,3072*1024);emit({'stage':'regression-complete','case':name,'worker':w});assert w['reason']=='completed'and w['cleanup_complete'],name
emit({'stage':'complete'})
