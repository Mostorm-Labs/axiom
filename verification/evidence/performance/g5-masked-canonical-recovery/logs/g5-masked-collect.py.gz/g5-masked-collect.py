from pathlib import Path
import json,gzip,shutil,hashlib,subprocess,platform
R=Path.cwd();S=R/'out/g5-masked-final';D=R/'verification/evidence/performance/g5-masked-canonical-recovery'
def load(p):return json.loads(gzip.decompress(p.read_bytes()))if p.suffix=='.gz'else json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(p,d):
 d.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix=='.log':d=d.with_suffix('.log.gz');d.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 else:shutil.copyfile(p,d)
code=subprocess.check_output(['git','rev-parse','82291be6'],text=True).strip();baseline=load(R/'out/g5-masked-baseline-final-on-dpr2/observation.json.gz');assert baseline['status']=='REPRODUCED_CANONICAL_CPU_TAIL'and baseline['sourceStable']and baseline['artifactStable']
bodies={p.parent.name:load(p)for p in S.glob('candidate*/observation.json.gz')};assert len(bodies)==6
summary={};pairs={}
def checkpoints(b):return[b['initial'],*[x['after']for x in b['phases']],b['undo'],b['redo']]
for name,b in {'baseline-on-dpr2':baseline,**bodies}.items():
 required=name in ['candidate-on-dpr2','candidate-off-dpr2','candidate-on-dpr2-repeat','candidate-on-dpr2-total'];assert b['sourceStable']and b['artifactStable']and not b['sourceBefore']['dirty']and not b['sourceAfter']['dirty'];assert all(b['historyChecks'].values())and b['close']['closed']and not b['close']['errors']and not b['errors'];assert all(all(x['raw']['checks'].values())for x in b['phases'])
 if name.startswith('candidate'):assert b['setup']['build']['sourceRevision']==code and not b['setup']['build']['dirty'];assert b['status']in(['MEASURED']if required else['MEASURED','BLOCKED_ENDPOINT'])
 rows=[]
 for p in b['phases']:
  raw=p['raw'];frames=[json.loads(r['text'][19:])for r in raw['nativeRecords']if r['at']>=raw['upAt']and r['text'].startswith('AXIOM_FRAME_TIMING ')];inclusive=sum(f['stages'].get('cpu_coverage',{}).get('inclusive_ns',0)for f in frames)/1e6;canonicalTotal=sum(f['stages']['attempt']['inclusive_ns']for f in frames)/1e6;cpuBefore={x['name']:x['value']for x in p['cpuBefore']};cpuAfter={x['name']:x['value']for x in p['cpuAfter']};
  if required and frames:assert inclusive<1500 and p['timing']['maxCanonicalAttemptMs']<500
  rows.append({'timing':{**p['timing'],'cpuCoverageExclusiveMs':sum(f['stages'].get('cpu_coverage',{}).get('exclusive_ns',0)for f in frames)/1e6 if frames else None,'cpuCoverageMs':inclusive if frames else None,'canonicalTotalMs':canonicalTotal if frames else None,'browserTaskCpuMs':(cpuAfter['TaskDuration']-cpuBefore['TaskDuration'])*1000,'maxCanonicalAttemptMs':p['timing']['maxCanonicalAttemptMs']if frames else None},'diagnosticCanonicalAttempts':len(frames),'canonicalRecordKnots':sum(f.get('counts',{}).get('compiled_contour_knots',0)for f in frames),'upMs':raw['upMs'],'endpoint':p['endpoint'],'feedback':p['feedback'],'maxRafCallbackMs':max(r['ended']-r['started']for r in raw['rafCallbacks']),'checks':raw['checks']})
 summary[name]={'status':b['status'],'blocking':required,'dpr':b['dpr'],'profiled':b['profiled'],'source':b['sourceBefore']['commit'],'build':b['setup']['build'],'phases':rows,'history':b['historyChecks']}
 if name.startswith('candidate'):
  x,y=checkpoints(baseline),checkpoints(b);v={'checkpoints':len(x),'exportPixels':all(i['image']['sha256']==j['image']['sha256']for i,j in zip(x,y)),'snapshotBytes':all(i['snapshot']['sha256']==j['snapshot']['sha256']for i,j in zip(x,y)),'compositorHashesEqual':[i['raw']['pixels']['sha256']==j['raw']['pixels']['sha256']for i,j in zip(baseline['phases'],b['phases'])]};assert v['exportPixels']and v['snapshotBytes'],(name,v);pairs[name]=v
assert load(S/'gpu.json')['status']=='PASS'
for name in ['dense','mixed']:
 b=load(S/name/'observation.json.gz');assert b['status']=='MEASURED'and b['sourceStable']and b['artifactStable']
for name in ['capacity','rejected-pixels']:
 b=load(S/(name+'.json'));assert b['status']in['PASS','MEASURED']and all(b['checks'].values())
native=load(S/'native-comparison.json');assert native['passed']==1013 and native['total']==1079 and not native['new_failed_names']
workers=[load(p)for p in S.glob('*.worker.json')];assert len(workers)==11 and all(w['cleanup_complete']for w in workers)
# Corroborative DPR1/4 endpoints remain findings if unmet;correctness still blocks.
assert all(w['reason']=='completed'or w['last_stage'].get('status')=='BLOCKED_ENDPOINT'for w in workers)
D.mkdir(exist_ok=True);snapshotIndex={}
for directory,label in [(S,'raw'),(R/'out/g5-masked-baseline-final-on-dpr2','raw/baseline-on-dpr2')]:
 for p in directory.rglob('*'):
  if not p.is_file():continue
  rel=Path(label)/p.relative_to(directory)
  if p.suffix=='.axsnap':
   h=sha(p);q=D/'raw/snapshots'/(h+'.axsnap.gz');q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists():q.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
   snapshotIndex[str(rel)]={'sha256':h,'bytes':p.stat().st_size,'stored':str(q.relative_to(D))}
  else:copy(p,D/rel)
write(D/'raw/snapshot-index.json',snapshotIndex)
copy(R/'out/g5-masked-baseline-final-on-dpr2-worker.worker.json',D/'raw/baseline-worker.json')
for p in R.glob('out/g5-masked-*'):
 if p.is_file()and p.suffix in['.log','.py','.mjs']:copy(p,D/'logs'/p.name)
for folder,label in [('out/g5-duplicate-erase-probe-data','profile-discovery'),('out/g5-masked-baseline-on-dpr2','runner-close-defect')]:
 for p in (R/folder).glob('*.gz'):copy(p,D/'exploratory'/label/p.name)
copy(R/'out/g5-duplicate-erase-probe.mjs',D/'exploratory/profile-discovery/probe.mjs')
write(D/'summary.json',summary);write(D/'paired-content.json',pairs)
packages={}
for name,root in [('baseline-on',R/'out/g5-erase-on/js'),('candidate-on',R/'out/g5-masked-on/js'),('candidate-off',R/'out/g5-masked-off/js')]:
 files=sorted(p for p in root.rglob('*')if p.is_file());meta=load(root/'package.json');assert len(files)==36 and list(meta['exports'])==['.']and not any(p.suffix in['.h','.hpp','.a']for p in files);packages[name]={'root':str(root),'version':meta['version'],'files':{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in files}}
write(D/'packages.json',packages)
invariants={}
for p in ['runtime/semantic/src/codec.cpp','runtime/semantic/src/snapshot.cpp','semantic-sdk.lock.json','r1-full-skia-sdk.lock.json','sdk/version.json','sdk/web/axiom.mjs','sdk/web/axiom.d.mts','sdk/windows/include/axiom/api.h','runtime/render/include/canvas/render/render_cache.hpp']:
 row={'sha256':sha(R/p),'unchangedFromAnchor':subprocess.check_output(['git','show','137e70af:'+p])==(R/p).read_bytes()};assert row['unchangedFromAnchor'];invariants[p]=row
write(D/'execution-inputs.json',{'anchor':'137e70af294107c4de23a62051d103be30d14e20','package':{'path':'docs/planning/G5_MASKED_CANONICAL_RECOVERY_2026_11_07.json','sha256':sha(R/'docs/planning/G5_MASKED_CANONICAL_RECOVERY_2026_11_07.json')},'webArtifactRevision':code,'productionRenderRevision':subprocess.check_output(['git','rev-parse','5cb9a102'],text=True).strip(),'verificationRevision':bodies['candidate-on-dpr2-total']['sourceBefore']['commit'],'nativeRenderBinarySha256':sha(R/'out/host/runtime/render/axiom_render_cache_tests'),'baselineSourceBefore':baseline['sourceBefore'],'baselineSourceAfter':baseline['sourceAfter'],'sourceBefore':bodies['candidate-on-dpr2']['sourceBefore'],'sourceAfter':bodies['candidate-on-dpr2']['sourceAfter'],'platform':platform.platform(),'machine':platform.machine(),'unchanged':invariants})
findings=[name for name,b in summary.items()if name.startswith('candidate')and any(p['timing']['cpuCoverageMs']is not None and p['timing']['cpuCoverageMs']>=1500 for p in b['phases'])];write(D/'result.json',{'status':'READY_FOR_CONTROL_REVIEW','officialGatePassClaimed':False,'scope':'Defaultv4 permanent-mask canonical preparation;local20s-style duplicate15,sequentialerase+immediate navigation engineering repair;not physical/Vibe/scale/release/Gate qualification','webArtifactRevision':code,'productionFiles':['runtime/render/src/skia_render_cache.cpp'],'privateTestBuildFix':'sdk/web/CMakeLists.txt fno-rtti matches locked Skia;no dependency rebuild or public install change','native':native,'checks':{'maskedOracle':'RED/GREEN','g5Node':42,'runtimeBoundaries':119,'collector':True,'GPU_Direct_PixelTolerance':2,'sequentialCandidateWorkers':6,'otherBrowserRegressions':4,'requiredDefaultDpr2Endpoints':True,'allWorkerCleanup':True},'budgetsMiB':{'optional':32,'shared':96},'corroborativeEndpointFindings':findings,'remaining':['Same66existingnativefailed/not-built names','PhysicalMac anduserunsaved4261document not directly mutated orqualified','Initialerasurefeedbackwarm-up andotherunqualifiedpaths are reported separately;CPUpercent equality toVibe not claimed']})
print(json.dumps({'destination':str(D),'workers':len(workers),'findings':findings,'status':'READY_FOR_CONTROL_REVIEW'}))
