import importlib.util,json,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
class RepairRunnerTest(unittest.TestCase):
 def module(self):
  path=ROOT/'verification/runners/g5/ur0/repair_runner.py';self.assertTrue(path.is_file(),'P36 bounded continuation runner missing')
  spec=importlib.util.spec_from_file_location('repair_runner',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
 def test_original_and_new_worker_envelopes_share_one_unchanged_cap(self):
  m=self.module();plan=m.plan();self.assertEqual(sum(r['limit_seconds'] for r in plan),7740)
  self.assertEqual(sum(r['phase']=='diagnostic' for r in plan),2);self.assertEqual(sum(r['phase']=='qualification' for r in plan),12)
  self.assertEqual(len({r['run_id'] for r in plan}),len(plan));self.assertLessEqual(sum(r['limit_seconds'] for r in plan),8370)
 def test_new_qualification_order_and_no_replacement_of_a_failed_pair(self):
  m=self.module();rows=m.plan();q=[r for r in rows if r['phase']=='qualification']
  self.assertEqual([r['toggle'] for r in q],['OFF','ON','ON','OFF','ON','OFF','OFF','ON','OFF','ON','ON','OFF'])
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'ledger.json';m.claim(path,rows,'diagnostic');saved=json.loads(path.read_text());saved[3]['status']='RSS_LIMIT';path.write_text(json.dumps(saved))
   with self.assertRaisesRegex(RuntimeError,'preserve|claimed|retry'):m.claim(path,rows,'diagnostic')
 def test_hard_guard_stop_cannot_be_interpreted_as_product_red(self):
  m=self.module();self.assertTrue(m.hard_stop({'reason':'rss_limit','cleanup_complete':True,'returncode':0}))
  self.assertTrue(m.hard_stop({'reason':'completed','cleanup_complete':True,'returncode':124}))
  self.assertFalse(m.hard_stop({'reason':'completed','cleanup_complete':True,'returncode':0}))
if __name__=='__main__':unittest.main()
