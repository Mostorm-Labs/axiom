import {SDK_VERSION, AxiomError} from './api/axiom.mjs';
import {adaptController} from './api/internal/controller.mjs';
export {SDK_VERSION, AxiomError};
/** Async, DOM-free control contract shared with the native SDK. */
export async function createController(options) {return adaptController(await createRuntime(options));}
const enumValue = (values, name) => {
  if (!Object.hasOwn(values, name)) throw new AxiomError('INVALID_ARGUMENT', `Unknown value: ${name}`);
  return values[name];
};
let serial = 0;
const newId=()=>{if(!globalThis.crypto?.randomUUID)throw new AxiomError('SECURE_CONTEXT_REQUIRED','Provide an Id128 or use HTTPS/localhost');return crypto.randomUUID().replaceAll('-','');};
/** Create an isolated Runtime. Commands resolve after apply, not persistence. */
export async function createRuntime({mount, documentId, restore, initialResources, builtinFonts = true, permission = 'unconfigured',
  assetBaseURL = new URL('.', import.meta.url), onOperation, onError, onFrame, onChange} = {}) {
  if(typeof HTMLElement==='undefined')throw new AxiomError('UNSUPPORTED_ENVIRONMENT','A browser DOM and WebGL2 are required');
  documentId ??= newId();
  if (!(mount instanceof HTMLElement) || mount.children.length || !/^[0-9a-f]{32}$/.test(documentId) || /^0+$/.test(documentId))
    throw new AxiomError('INVALID_ARGUMENT', 'An empty mount element and a nonzero Id128 are required');
  const canonical = document.createElement('canvas'), preview = document.createElement('canvas'), retained = document.createElement('canvas');
  const id = `axiom-sdk-${++serial}-${Math.random().toString(36).slice(2)}`;
  canonical.id = `${id}-canonical`; preview.id = `${id}-preview`;
  retained.id = `${id}-retained`;
  const oldPosition = mount.style.position;
  const oldOverflow = mount.style.overflow;
  const positioned = getComputedStyle(mount).position === 'static';
  if (positioned) mount.style.position = 'relative';
  mount.style.overflow = 'hidden';
  for (const canvas of [canonical, preview, retained]) Object.assign(canvas.style, {position:'absolute',top:'0',left:'0'});
  canonical.style.touchAction = 'none'; canonical.style.zIndex = '0';
  preview.style.pointerEvents = 'none'; preview.style.visibility = 'hidden'; preview.style.zIndex = '1';
  retained.style.pointerEvents = 'none'; retained.style.visibility = 'hidden'; retained.style.zIndex = '2';
  mount.append(canonical, preview);
  let module, closed = false, closing = false, scheduled = 0, observer, disposeInput, text, lastPresented = '0', tail = Promise.resolve();
  let boundWidth=0,boundHeight=0,boundDpr=0,pendingResize=false,resizeTimer=0;
  let retainedActive=false;
  let closeBarrier=false;
  const listeners=new Map();let listenerSequence=0;
  const emitError = error => { if (onError) queueMicrotask(() => {if(!closed)onError(error);}); };
  const call = (command, args = {}, bytes) => {
    if (closed) throw new AxiomError('CLOSED');
    if(bytes!==undefined && (Object.prototype.toString.call(bytes)!=='[object Uint8Array]'||bytes.length>134217728))throw new AxiomError('INVALID_ARGUMENT','Expected at most 128 MiB of bytes');
    let input = 0, data = 0;
    try {
      let serialized;
      try{serialized=JSON.stringify({command,...args});}catch(error){throw new AxiomError('INVALID_ARGUMENT',String(error));}
      input = module.stringToNewUTF8(serialized);
      if (!input) throw new AxiomError('OUT_OF_MEMORY');
      if (bytes?.length) { data = module._malloc(bytes.length); if (!data) throw new AxiomError('OUT_OF_MEMORY'); module.HEAPU8.set(bytes, data); }
      const result = JSON.parse(module.UTF8ToString(module._axiom_js_call(input, data, bytes?.length || 0)));
      if (!result.ok) throw new AxiomError(result.code || 'REJECTED', result.message || result.code, result);
      return result;
    } finally { if (input) module._free(input); if (data) module._free(data); }
  };
  const changed=()=>schedule();
  const packetValue=value=>value?{...value,owner:id}:null;
  const packetMetadata=packet=>{const {bytes,...metadata}=packet;return metadata;};
  const readPacket=after=>{
    if(after&&after.owner!==id)throw new AxiomError('WRONG_RUNTIME');
    const result=call('data',{action:'next',after:after?packetMetadata(after):null});
    return result.value?{...packetValue(result.value),bytes:module.HEAPU8.slice(module._axiom_js_bytes(),module._axiom_js_bytes()+module._axiom_js_size())}:null;
  };
  const listenerError=error=>new AxiomError('EVENT_LISTENER_FAILED',String(error));
  const dispatch=()=>{
    if(closed)return;
    for(const [token,s] of listeners){
      if(s.paused)continue;
      try{
        if(s.kind==='operation')for(let n=0;n<64&&listeners.has(token);++n){
          const packet=readPacket(s.cursor);if(!packet)break;
          const result=s.fn(packet);if(result?.then){result.catch?.(()=>{});throw new AxiomError('ASYNC_LISTENER','Transfer to your queue synchronously; report durability later');}
          if(listeners.has(token))s.cursor=packetMetadata(packet);
          if(n===63)schedule();
        }
        else if(s.kind==='state'){
          const value=call('state').value,key=JSON.stringify(value);
          if(key!==s.last){const result=s.fn(value);if(result?.then){result.catch?.(()=>{});throw new AxiomError('ASYNC_LISTENER');}s.last=key;}
        }
      }catch(error){s.paused=true;emitError(error instanceof AxiomError?error:listenerError(error));}
    }
  };
  const render = () => {
    scheduled = 0; if (closed || closing) return;
    try {
      const frame = call('frame');
      if (retainedActive && !pendingResize && frame.surfaceReady) {
        retained.remove();retained.width=retained.height=0;retainedActive=false;
      }
      dispatch();
      if (frame.presented && frame.presented !== lastPresented) {
        lastPresented = frame.presented;
        if(onFrame)queueMicrotask(()=>{if(!closed)try{const result=onFrame({presented:frame.presented});result?.catch?.(error=>emitError(listenerError(error)));}catch(error){emitError(listenerError(error));}});
      }
      if (frame.pending || frame.retry || text?.snapshot().phase) schedule();
    } catch(error) { emitError(error); }
  };
  const schedule = () => { if(!closed && !closing && !scheduled)scheduled=requestAnimationFrame(render); };
  const enqueue = (fn, finish = true, notify = true) => {
    if(closing || closed || closeBarrier)return Promise.reject(new AxiomError(closeBarrier?'DOCUMENT_CLOSING':'CLOSED'));
    const task = tail.then(async()=>{if(closed)throw new AxiomError('CLOSED');if(finish)await text?.finish();const result=await fn();if(notify){changed();schedule();}return result;});
    tail=task.catch(()=>{});return task;
  };
  const cleanup = () => {
    listeners.clear();
    cancelAnimationFrame(scheduled); clearTimeout(resizeTimer); observer?.disconnect(); disposeInput?.(); text?.dispose();
    for(const [name,fn,options] of events)canonical.removeEventListener(name,fn,options);
    canonical.remove();preview.remove();retained.remove();if(positioned&&mount.style.position==='relative')mount.style.position=oldPosition;
    if(mount.style.overflow==='hidden')mount.style.overflow=oldOverflow;
  };
  const sizeDisplay = (canvas, width, height) => {
    canvas.style.width = `${width}px`;canvas.style.height = `${height}px`;
  };
  const retainVisibleFrame = () => {
    if (retainedActive) return true;
    if (!canonical.width || !canonical.height) return false;
    try {
      retained.width = canonical.width;retained.height = canonical.height;
      sizeDisplay(retained,boundWidth,boundHeight);
      const pixels=retained.getContext('2d');
      pixels.drawImage(canonical,0,0);
      if(preview.style.visibility==='visible')pixels.drawImage(preview,0,0);
      // A retained frame is display continuity only. Its logical pixel size
      // and origin stay fixed while the mount reveals/clips the old viewport.
      retained.style.visibility = 'visible';mount.append(retained);retainedActive = true;
      return true;
    } catch { retained.remove();retained.width=retained.height=0;retainedActive = false;return false; }
  };
  const resize = () => {
    clearTimeout(resizeTimer);resizeTimer=0;
    const rect=mount.getBoundingClientRect(), dpr=devicePixelRatio || 1;
    if(!(rect.width>0 && rect.height>0 && rect.width*dpr<=16384 && rect.height*dpr<=16384))throw new AxiomError('INVALID_SIZE','Mount dimensions exceed the supported surface range');
    const state=call('state').value;
    if(state.activeContacts){pendingResize=true;return;}
    if(state.surface.available && rect.width===boundWidth && rect.height===boundHeight && dpr===boundDpr){pendingResize=false;schedule();return;}
    if (boundWidth > 0 && boundHeight > 0) retainVisibleFrame();
    canonical.width=preview.width=Math.round(rect.width*dpr);canonical.height=preview.height=Math.round(rect.height*dpr);
    sizeDisplay(canonical,rect.width,rect.height);sizeDisplay(preview,rect.width,rect.height);
    call('resize',{width:rect.width,height:rect.height,dpr});boundWidth=rect.width;boundHeight=rect.height;boundDpr=dpr;pendingResize=false;schedule();
  };
  const requestResize = () => {
    if(closed||closing)return;
    const rect=mount.getBoundingClientRect(),dpr=devicePixelRatio||1;
    if(rect.width===boundWidth&&rect.height===boundHeight&&dpr===boundDpr)return;
    pendingResize=true;clearTimeout(resizeTimer);
    // Native window resizing generates many observations. Keep old pixels at
    // 1:1 logical size, then bind only the latest dimensions after it settles.
    resizeTimer=setTimeout(()=>{
      resizeTimer=0;if(closed||closing)return;
      try{resize();text.sync();}catch(error){if(error.code!=='BUSY')emitError(error);}
    },120);
  };
  const events = [];
  try {
    const factory = (await import(new URL('internal/axiom.mjs', import.meta.url))).default;
    const assets=new URL(assetBaseURL,import.meta.url);
    module=await factory({canvas:canonical,locateFile:name=>new URL(name,assets).href,
      onPreview:visible=>{preview.style.visibility=visible?'visible':'hidden';},
      onLocalOperation:bytes=>{if(onOperation)queueMicrotask(()=>{if(!closed)try{const result=onOperation(bytes);if(result?.catch)result.catch(error=>emitError(listenerError(error)));}catch(error){emitError(listenerError(error));}});},
      onDeliveryError:()=>emitError(new AxiomError('OPERATION_DELIVERY_FAILED'))});
    if(['_axiom_js_call','_axiom_js_bytes','_axiom_js_size','_malloc','_free','UTF8ToString','stringToNewUTF8'].some(key=>typeof module[key]!=='function'))throw new AxiomError('INCOMPATIBLE_ENGINE');
    if(call('version').apiVersion!==1||call('version').features?.shellAxis!==1)throw new AxiomError('INCOMPATIBLE_ENGINE');
    const initial=mount.getBoundingClientRect(),dpr=devicePixelRatio||1;
    if(!(initial.width>0&&initial.height>0))throw new AxiomError('INVALID_SIZE');
    canonical.width=preview.width=Math.round(initial.width*dpr);canonical.height=preview.height=Math.round(initial.height*dpr);
    sizeDisplay(canonical,initial.width,initial.height);sizeDisplay(preview,initial.width,initial.height);
    call('open',{documentId,builtinFonts,width:initial.width,height:initial.height,dpr,canonical:`#${canonical.id}`,preview:`#${preview.id}`,...(restore?{restore:restore.metadata}:{}),...(initialResources?{initialResources}:{})},restore?.bytes);
    boundWidth=initial.width;boundHeight=initial.height;boundDpr=dpr;
    call('multi',{action:'permission',mode:enumValue({unconfigured:0,localSingleUser:1,contextUnavailable:2},permission)});
    resize();
    const [{installPointerInput},{installTextInput}]=await Promise.all([import('./pointer_input.mjs'),import('./text_input.mjs')]);
    text=installTextInput({module,handle:1,canvas:canonical,stage:mount,schedule});
    mount.querySelector('textarea').id=`${id}-ime`;
    // Flush final native metrics before the collector translates a new Down.
    // Active contacts keep their existing binding until the last Up/Cancel.
    const inputSize=()=>{if(pendingResize)try{resize();text.sync();}catch(error){emitError(error);}};
    canonical.addEventListener('pointerdown',inputSize,true);
    events.push(['pointerdown',inputSize,true]);
    disposeInput=installPointerInput({canvas:canonical,logicalSize:()=>[boundWidth,boundHeight],submit:fact=>{
      try{call('pointer',fact);text.sync();if(pendingResize&&fact.phase>=2)resize();changed();schedule();return true;}catch(error){emitError(error);schedule();return false;}
    }});
    const listen=(name,fn,options)=>{canonical.addEventListener(name,fn,options);events.push([name,fn,options]);};
    listen('dblclick',event=>{const s=call('state').value;if(s.tool!==4 && !(s.tool===1&&s.selectionMode===0))event.stopImmediatePropagation();},true);
    listen('pointermove',e=>{if(e.pointerType==='mouse'&&!e.buttons){const r=canonical.getBoundingClientRect();try{call('hover',{x:e.clientX-r.left,y:e.clientY-r.top});schedule();}catch(error){emitError(error);}}});
    const clearHover=()=>{try{call('hover',{x:-1,y:-1});schedule();}catch(error){emitError(error);}};
    listen('pointerleave',clearHover);
    window.addEventListener('blur',clearHover);

    listen('wheel',e=>{e.preventDefault();const r=canonical.getBoundingClientRect();try{
      if(e.ctrlKey){const s=call('state').value;call('control',{kind:'zoom',x:e.clientX-r.left,y:e.clientY-r.top,scale:s.camera.scale*Math.exp(-e.deltaY*.01)});}
      else call('control',{kind:'pan',x:e.deltaX,y:e.deltaY});text.sync();schedule();
    }catch(error){emitError(error);}},{passive:false});
    const contextLost=e=>{e.preventDefault();retainVisibleFrame();try{inputCleanup.cancelAll();call('lose');}catch(error){emitError(error);}};
    const contextRestored=()=>{if(!canonical.getContext('webgl2').isContextLost()&&!preview.getContext('webgl2').isContextLost())try{resize();}catch(error){emitError(error);}};
    for(const c of [canonical,preview]){c.addEventListener('webglcontextlost',contextLost);c.addEventListener('webglcontextrestored',contextRestored);}
    const inputCleanup=disposeInput;disposeInput=()=>{window.removeEventListener('blur',clearHover);inputCleanup();for(const c of [canonical,preview]){c.removeEventListener('webglcontextlost',contextLost);c.removeEventListener('webglcontextrestored',contextRestored);}};
    observer=new ResizeObserver(requestResize);observer.observe(mount);
    const control=async args=>{
      const selected=['size','transform','delete','lock','visible','unlock','order'].includes(args.kind)||(args.kind==='appearance'&&args.selected!==false);
      const stamp=selected?call('state').value:null;
      return enqueue(()=>call('control',{...args,...(stamp?{expectedGeneration:stamp.generation,expectedSelectionRevision:stamp.selectionRevision}:{})}));
    };
    const readAppearance=(defaults=false)=>{
      const result=call('appearance',{action:defaults?'readDefaults':'read'}).value;
      return {...result,stamp:{owner:id,token:result.stamp}};
    };
    const appearanceCommand=(action,patch,observation,token)=>{
      let request,foreign=false;try{
        if(observation)foreign=observation.stamp?.owner!==id;
        if(token)foreign=foreign||token.owner!==id;
        request=structuredClone({action,...(patch===undefined?{}:{patch}),...(observation?{stamp:observation.stamp?.token,eligible:observation.eligible}:{}),...(token?{token:{stamp:token.stamp,serial:token.serial}}:{})});
      }catch(error){return Promise.reject(new AxiomError('INVALID_ARGUMENT',String(error)));}
      return enqueue(()=>{
        if(foreign){try{call('appearance',{action:'cancel',token:{stamp:Array(8).fill('0'),serial:'0'}});}catch{}throw new AxiomError('WRONG_RUNTIME');}
        const result=call('appearance',request);return {...result,token:{...result.token,owner:id}};
      },false);
    };
    const tableOptions=(action,options={})=>{
      const fields={create:['rows','columns','x','y'],select:['objectId','rowId','columnId'],insertRow:['objectId','index'],insertColumn:['objectId','index'],removeRow:['objectId','rowId','columnId'],removeColumn:['objectId','rowId','columnId'],rowHeight:['objectId','rowId','columnId','size'],columnWidth:['objectId','rowId','columnId','size'],cellStyle:['objectId','rowId','columnId','fill','format'],gridStyle:['objectId','color','width'],next:[],previous:[]}[action];
      if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>k!=='generation'&&!fields.includes(k)))throw new AxiomError('INVALID_ARGUMENT');
      const request={...options};for(const key of ['fill','color'])if(Array.isArray(request[key]))request[key]=[...request[key]];
      if(request.format&&typeof request.format==='object'){request.format={...request.format};if(Array.isArray(request.format.color))request.format.color=[...request.format.color];}
      return request;
    };
    const tableCommand=(action,options={})=>{
      let request;try{request=tableOptions(action,options);request.generation??=call('state').value.generation;}catch(error){return Promise.reject(error);}
      return enqueue(()=>{const result=call('table',{...request,action});
        // Runtime owns editor entry. The adapter only gives that local editor
        // its native input focus, including programmatic Table creation.
        if(action==='create'&&text.snapshot().phase!==0){canonical.focus({preventScroll:true});text.sync();}
        return result;});
    };
    const tableEdit=options=>{
      let request;try{request=tableOptions('select',options);request.generation??=call('state').value.generation;}catch(error){return Promise.reject(error);}
      return enqueue(async()=>{const r=call('table',{...request,action:'select'});canonical.focus({preventScroll:true});await text.intent(1,{object:r.objectId,row:request.rowId,column:request.columnId});if(text.error())throw new AxiomError('TEXT_REJECTED',text.error());return text.snapshot();});
    };
    const section=(action,options={})=>enqueue(()=>call('section',{action,...options}));
    const textIntent=(kind,options={})=>enqueue(async()=>{const result=await text.intent(kind,options);if(text.error())throw new AxiomError('TEXT_REJECTED',text.error());return result;},false);
    const owned=(value)=>{if(!value||value.owner!==id)throw new AxiomError('WRONG_RUNTIME');return value;};
    const subscribe=(kind,fn)=>{
      if(closed||closing||closeBarrier)throw new AxiomError(closeBarrier?'DOCUMENT_CLOSING':'CLOSED');
      if(typeof fn!=='function'||listeners.size>=64)throw new AxiomError('INVALID_ARGUMENT');
      const cursor=kind==='operation'?packetValue(call('data',{action:'attach'}).value.latest):null;
      const token=++listenerSequence;listeners.set(token,{kind,fn,cursor,last:null,paused:false});schedule();
      return ()=>{listeners.delete(token);};
    };
    if(onChange)subscribe('state',onChange);
    const api={
      version:SDK_VERSION, canvas:canonical,
      readBuildInfo:()=>call('version'),
      readState:()=>call('state').value,
      exportImage:async (options={})=>{
        const keys=['format','scale','padding','quality','background','includePattern','bounds','generation'];
        if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(key=>!keys.includes(key)))throw new AxiomError('INVALID_ARGUMENT');
        const value={};
        for(const key of Object.keys(options)){
          const input=options[key];
          if(key==='format'&&!['png','jpg','jpeg'].includes(input)||
             key==='scale'&&!(typeof input==='number'&&Number.isFinite(input)&&input>0)||
             key==='quality'&&!(typeof input==='number'&&Number.isFinite(input)&&input>=0&&input<=1)||
             key==='padding'&&!(Number.isInteger(input)&&input>=0&&input<=1024)||
             key==='includePattern'&&typeof input!=='boolean'||
             key==='generation'&&!(typeof input==='string'&&/^(0|[1-9][0-9]*)$/.test(input)&&BigInt(input)<=18446744073709551615n)||
             key==='bounds'&&!(Array.isArray(input)&&input.length===4&&input.every(n=>typeof n==='number'&&Number.isFinite(n))&&input[0]<input[2]&&input[1]<input[3])||
             key==='background'&&!(input==='document'||input==='transparent'||Array.isArray(input)&&input.length===4&&input.every(n=>typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=1)&&input[3]===1))
            throw new AxiomError('INVALID_ARGUMENT');
          value[key]=Array.isArray(input)?[...input]:input;
        }
        if(value.background==='transparent'&&value.format&&value.format!=='png')throw new AxiomError('INVALID_ARGUMENT','Transparent background requires PNG');
        return enqueue(()=>{const result=call('exportImage',{options:value});return {...result.value,bytes:module.HEAPU8.slice(module._axiom_js_bytes(),module._axiom_js_bytes()+module._axiom_js_size())};},false,false);
      },
      readBackground:()=>call('background').value,
      setBackground:async value=>{
        if(!value||typeof value!=='object'||Object.keys(value).length!==3||
          !['plain','dots','grid'].includes(value.mode)||
          ![value.color,value.patternColor].every(c=>Array.isArray(c)&&c.length===4&&c.every(n=>typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=1))||
          value.color[3]!==1)throw new AxiomError('INVALID_ARGUMENT');
        return control({kind:'background',value:{mode:value.mode,color:[...value.color],patternColor:[...value.patternColor]}});
      },
      copySelection:()=>{const result=call('clipboard',{action:'copy'});return {...result.value,stamp:{owner:id,token:result.value.stamp},bytes:module.HEAPU8.slice(module._axiom_js_bytes(),module._axiom_js_bytes()+module._axiom_js_size())};},
      cutSelection:stamp=>{let captured;try{captured=structuredClone(owned(stamp).token);}catch(error){return Promise.reject(error instanceof AxiomError?error:new AxiomError('INVALID_ARGUMENT'));}return enqueue(()=>call('clipboard',{action:'cut',stamp:captured}));},
      duplicateSelection:(options={})=>{let value;try{if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>k!=='offset')||options.offset!==undefined&&!(Array.isArray(options.offset)&&options.offset.length===2&&options.offset.every(n=>typeof n==='number'&&Number.isFinite(n))))throw new AxiomError('INVALID_ARGUMENT');value={...structuredClone(options),stamp:call('multi',{action:'read'}).value.stamp};}catch(error){return Promise.reject(error);}return enqueue(()=>call('clipboard',{...value,action:'duplicate'}));},
      pasteObjects:(bytes,options={})=>{if(Object.prototype.toString.call(bytes)!=='[object Uint8Array]'||bytes.length>16777216)return Promise.reject(new AxiomError('INVALID_ARGUMENT'));let value;try{if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>k!='offset')||options.offset!==undefined&&!(Array.isArray(options.offset)&&options.offset.length===2&&options.offset.every(n=>typeof n==='number'&&Number.isFinite(n))))throw new AxiomError('INVALID_ARGUMENT');value={...structuredClone(options),stamp:call('multi',{action:'read'}).value.stamp};}catch(error){return Promise.reject(error);}const captured=bytes.slice();return enqueue(()=>call('clipboard',{...value,action:'paste'},captured));},
      readSelection:()=>call('selection').value,
      subscribeOperations:fn=>subscribe('operation',fn),subscribeState:fn=>subscribe('state',fn),
      dispatchEvents:()=>Promise.resolve().then(()=>{if(closed)throw new AxiomError('CLOSED');for(const s of listeners.values())s.paused=false;dispatch();}),
      data:{attach:options=>{const s=call('data',{action:'attach',...options}).value;return {...s,latest:packetValue(s.latest)};},
        status:()=>{const s=call('data',{action:'status'}).value;return {...s,latest:packetValue(s.latest)};},
        readNext:after=>readPacket(after),
        release:packet=>{const result=call('data',{action:'release',packet:packetMetadata(owned(packet))});schedule();return result;},
        reportStatus:(packet,localDurable,cloudSynced)=>{const result=call('data',{action:'report',packet:packetMetadata(owned(packet)),localDurable,cloudSynced});schedule();return result;}},
      selectTool:async name=>{const value=enumValue({ink:0,select:1,objectEraser:2,partialEraser:2,hand:3,text:4},name);return enqueue(()=>{const result=call('control',{kind:'tool',value});if(name.endsWith('Eraser'))call('control',{kind:'eraser',mode:name==='objectEraser'?1:2});return result;});},
      selectShape:async name=>control({kind:'shape',value:enumValue({rectangle:0,ellipse:1,triangle:2,line:3,arrow:4,sticky:5,table:6,section:7},name)}),
      setSelectionMode:async name=>control({kind:'selectionMode',value:enumValue({point:0,rectangle:1,lasso:2},name)}),
      setInk:options=>control({kind:'ink',...options}),setEraser:options=>control({kind:'eraser',...options}),
      brushPresets:()=>call('presets').value,selectBrush:(profileId,revision)=>control({kind:'preset',profileId,revision}),
      setBrushConfig:value=>control({kind:'inkBrush',value}),readBrushConfig:()=>call('readInkBrush').value,
      setAppearance:options=>control({kind:'appearance',...options}),orderSelection:front=>control({kind:'order',front}),
      undo:()=>control({kind:'undo'}),redo:()=>control({kind:'redo'}),panBy:(x,y)=>control({kind:'pan',x,y}),
      zoomAt:(x,y,scale)=>control({kind:'zoom',x,y,scale}),fitContent:()=>control({kind:'fit'}),
      fitSelection:()=>control({kind:'fit',target:1}),fitObject:objectId=>control({kind:'fit',target:2,objectId}),
      resizeSelection:(width,height)=>control({kind:'size',width,height}),transformSelection:matrix=>control({kind:'transform',matrix}),
      deleteSelection:()=>control({kind:'delete'}),lockSelection:value=>control({kind:'lock',value}),
      setSelectionVisible:value=>control({kind:'visible',value}),unlockSelection:()=>control({kind:'unlock'}),
      createSection:options=>section(0,options),wrapInSection:options=>section(1,options),releaseSection:objectId=>section(2,{objectId}),
      readSection:objectId=>call('readSection',objectId?{objectId}:{}).value,
      selectSection:objectId=>section(6,{objectId}),selectSectionChildren:objectId=>section(7,{objectId}),
      reparent:options=>section(3,options),resizeSection:(objectId,boundary)=>section(4,{objectId,boundary}),renameSection:(objectId,title)=>section(5,{objectId,title}),
      group:()=>enqueue(()=>{const s=call('state').value;return call('section',{action:10,objects:s.selected,generation:s.generation,selectionRevision:s.selectionRevision});}),
      ungroup:objectId=>enqueue(()=>{const s=call('state').value;return call('section',{action:11,objectId:objectId??s.primary,generation:s.generation,selectionRevision:s.selectionRevision});}),
      enterGroup:objectId=>enqueue(()=>{const s=call('state').value;return call('section',{action:8,objectId:objectId??s.primary});}),leaveGroup:()=>section(9),
      appearance:{
        read:()=>readAppearance(),
        readDefaults:()=>readAppearance(true),
        patch:(patch,observation=readAppearance())=>appearanceCommand('patch',patch,observation),
        setDefaults:patch=>appearanceCommand('defaults',patch),
        begin:(observation=readAppearance())=>appearanceCommand('begin',undefined,observation),
        updatePreview:(token,patch)=>appearanceCommand('preview',patch,undefined,token),
        commit:token=>appearanceCommand('commit',undefined,undefined,token),
        cancel:token=>appearanceCommand('cancel',undefined,undefined,token)
      },
      table:{
        create:options=>tableCommand('create',options),read:objectId=>call('table',{action:'read',...(objectId?{objectId}:{})}).value,
        select:options=>tableCommand('select',options),
        edit:tableEdit,
        navigate:direction=>tableCommand(enumValue({'1':'next','-1':'previous'},String(direction))),
        insertRow:options=>tableCommand('insertRow',options),insertColumn:options=>tableCommand('insertColumn',options),
        removeRow:options=>tableCommand('removeRow',options),removeColumn:options=>tableCommand('removeColumn',options),
        setRowHeight:options=>tableCommand('rowHeight',options),setColumnWidth:options=>tableCommand('columnWidth',options),
        setCellStyle:options=>tableCommand('cellStyle',options),setGridStyle:options=>tableCommand('gridStyle',options)},
      text:{read:()=>{if(closed)throw new AxiomError('CLOSED');return text.snapshot();},fonts:()=>{if(closed)throw new AxiomError('CLOSED');return text.fontCatalog();},fontStatus:id=>{if(closed)throw new AxiomError('CLOSED');return text.fontStatus(id);},
        create:(x,y,width=320)=>textIntent(0,{x,y,width}),edit:object=>textIntent(1,{object}),editAtPoint:(x,y)=>textIntent(13,{x,y}),
        replace:(value,range)=>{if(typeof value!=='string'||value.length>65536)return Promise.reject(new AxiomError('INVALID_ARGUMENT'));return enqueue(()=>{const s=text.snapshot();return call('textEdit',{kind:4,token:s.token,range:range??s.selection,units:Array.from({length:value.length},(_,i)=>value.charCodeAt(i))});},false);},
        select:(start,length)=>enqueue(()=>{const s=text.snapshot();return call('textEdit',{kind:5,token:s.token,range:[start,length]});},false),
        selectAll:()=>textIntent(12),backspace:()=>textIntent(8),delete:()=>textIntent(9),moveLeft:()=>textIntent(10),moveRight:()=>textIntent(11),
        escape:()=>textIntent(4),insertParagraph:()=>textIntent(3),setWidth:width=>textIntent(5,{width}),resync:()=>textIntent(7),retry:()=>textIntent(6),
        format:patch=>enqueue(async()=>{await text.intent(15,{format:patch});if(text.error())throw new AxiomError('TEXT_REJECTED',text.error());},false),
        finish:()=>enqueue(()=>text.finish(),false),completeComposition:()=>enqueue(()=>text.complete(),false)},
      multi:{read:()=>{const p=call('multi',{action:'read'}).value;p.stamp={owner:id,token:p.stamp};return p;},
        readValues:(field,stamp,eligible)=>call('multi',{action:'values',field,stamp:owned(stamp).token,eligible}).value,
        setPermission:mode=>enqueue(()=>call('multi',{action:'permission',mode:enumValue({unconfigured:0,localSingleUser:1,contextUnavailable:2},mode)})),
        setProperty:(field,value,stamp,eligible)=>enqueue(()=>call('multi',{action:'set',field,value,stamp:owned(stamp).token,eligible})),
        setStrokeWidth:(width,stamp,eligible)=>enqueue(()=>call('multi',{action:'width',width,stamp:owned(stamp).token,eligible}))},
      resources:{list:()=>{const value=call('resource',{action:'list'}).value;for(const e of value.entries)if(e.token)e.token.owner=id;return value;},
        readBytes:token=>{call('resource',{action:'bytes',token:owned(token)});return module.HEAPU8.slice(module._axiom_js_bytes(),module._axiom_js_bytes()+module._axiom_js_size());},
        token:objectId=>{const value=call('resource',{action:'token',objectId}).value;return value?{...value,owner:id}:null;},
        receipt:objectId=>{const value=call('resource',{action:'receipt',objectId}).value;if(value)value.token.owner=id;return value;},
        publish:(token,bytes)=>enqueue(()=>call('resource',{action:'publish',token:owned(token)},bytes),false)},
      importImage:(bytes,mime)=>enqueue(()=>call('image',{action:'import',mime},bytes)),
      readSelectedImage:()=>call('image',{action:'read'}).value,readCrop:()=>call('image',{action:'readCrop'}).value,
      replaceImage:(bytes,mime)=>enqueue(()=>call('image',{action:'replace',mime},bytes)),
      resizeImage:(objectId,width,height,freeStretch=false)=>enqueue(()=>call('image',{action:'resize',objectId,width,height,freeStretch})),
      beginCrop:objectId=>enqueue(()=>call('image',{action:'crop',objectId})),
      updateCrop:options=>enqueue(()=>call('image',{action:'update',...options})),
      commitCrop:token=>enqueue(()=>call('image',{action:'done',token})),cancelCrop:token=>enqueue(()=>call('image',{action:'cancel',token})),
      createVectorPath:options=>{let args;try{args=structuredClone(options);}catch(error){return Promise.reject(new AxiomError('INVALID_ARGUMENT',String(error)));}return enqueue(()=>call('vectorPath',{action:'create',...args}));},
      readVectorPath:objectId=>call('vectorPath',{action:'read',...(objectId?{objectId}:{})}).value,
      createConnector:options=>enqueue(()=>call('connector',{action:'create',...options,objectId:options?.objectId??newId()})),
      setConnectorRouting:options=>enqueue(()=>call('connector',{action:'routing',...options})),
      readConnector:objectId=>call('connector',{action:'read',...(objectId?{objectId}:{})}).value,
      createSticky:options=>enqueue(()=>call('sticky',{action:'create',...options,objectId:options?.objectId??newId()})),readSelectedSticky:()=>call('sticky',{action:'read'}).value,
      captureSnapshot:metadata=>enqueue(()=>{const result=call('snapshot',metadata);return {...result,bytes:module.HEAPU8.slice(module._axiom_js_bytes(),module._axiom_js_bytes()+module._axiom_js_size())};}),
      applyRemoteOperation:bytes=>enqueue(()=>call('remote',{},bytes)),
      applyReplayOperation:bytes=>enqueue(()=>call('replay',{},bytes)),
      applyReplayOperations:packets=>enqueue(()=>call('replayBatch',{packets:packets.map(p=>({operationId:p.operationId,bytes:Array.from(p.bytes)}))}).value),
      applyRemoteOperations:packets=>enqueue(()=>call('remoteBatch',{packets:packets.map(p=>({operationId:p.operationId,bytes:Array.from(p.bytes)}))}).value),
      async close(){if(closed)return;if(closing)throw new AxiomError('BUSY');closing=true;
        try{await tail;await text.finish();call('close');disposeInput?.();disposeInput=undefined;closed=true;cleanup();text=undefined;module=null;}
        catch(error){if(['PUBLICATION_PENDING','SHUTDOWN_FAILED','CLOSE_FAILED'].includes(error.code)){closeBarrier=true;disposeInput?.();disposeInput=undefined;text.dispose();}closing=false;schedule();throw error;}}
    };
    listen('keydown',e=>{if(e.ctrlKey||e.metaKey||e.altKey||e.isComposing||text.snapshot().phase!==0)return;const t=api.table.read();if(!t.available||!t.editable)return;
      if(e.key==='Tab'){e.preventDefault();void api.table.navigate(e.shiftKey?-1:1).catch(emitError);}
      if(e.key==='Enter'){e.preventDefault();void api.table.edit({objectId:t.objectId,rowId:t.rowId,columnId:t.columnId}).catch(emitError);}
    });
    schedule();return Object.freeze(api);
  } catch(error) {try{if(module)call('close');}catch{}closed=true;cleanup();throw error;}
}
