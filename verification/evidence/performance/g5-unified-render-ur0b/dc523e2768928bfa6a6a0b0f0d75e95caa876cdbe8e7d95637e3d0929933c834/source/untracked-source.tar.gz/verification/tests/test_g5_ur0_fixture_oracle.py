"""Run against the real non-installed offline oracle, not a mock decoder."""
import json, os, subprocess, tempfile, unittest
from pathlib import Path

class FixtureOracleTest(unittest.TestCase):
    def test_malformed_snapshot_is_rejected(self):
        executable=Path(os.environ.get('UR0_FIXTURE_ORACLE','out/host/runtime/render/axiom_ur0_fixture_oracle'))
        self.assertTrue(executable.is_file(), 'independent fixture decoder unavailable')
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'bad.axsnap';path.write_bytes(b'not a snapshot')
            run=subprocess.run([str(executable.resolve()),str(path)],capture_output=True,text=True)
            self.assertNotEqual(run.returncode,0)
            self.assertEqual(json.loads(run.stdout)['status'],'INVALID_SNAPSHOT')

if __name__=='__main__':unittest.main()
