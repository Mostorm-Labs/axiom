// Offline, non-installed qualification consumer. Decodes opaque snapshots and
// evaluates canonical geometry directly; never reads candidate cache pixels.
#include "canvas/semantic/snapshot.hpp"
#include "canvas/ink/brush_package_catalog.hpp"
#include "canvas/ink/brush_session.hpp"
#include "canvas/render/selection_region_geometry.hpp"
#include "../../../../runtime/interaction/src/partial_erase_geometry.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <iomanip>
#include <sstream>
using nlohmann::json;
using namespace canvas;
namespace {
std::string hex(foundation::ObjectId id){std::ostringstream o;for(auto b:id.bytes)o<<std::hex<<std::setfill('0')<<std::setw(2)<<unsigned(b);return o.str();}
json readJson(const char* p){std::ifstream f(p);if(!f)throw std::runtime_error("JSON file missing");json j;f>>j;return j;}
std::optional<semantic::SemanticSnapshot> decode(const char* p,json& out){
 std::ifstream f(p,std::ios::binary);if(!f)throw std::runtime_error("snapshot file missing");
 std::vector<std::uint8_t> bytes{std::istreambuf_iterator<char>(f),{}};
 auto result=semantic::SnapshotCodec::decode(bytes,semantic::SnapshotCapability::kAllWithCompactStrokeV1);
 out["decode_error"]=static_cast<unsigned>(result.error);out["byte_length"]=bytes.size();return std::move(result.snapshot);
}
RuntimeSceneRecord record(const semantic::ObjectRecord& r){RuntimeSceneRecord v;v.objectId=r.id;v.kind=r.kind;v.kindVersion=r.kind_version;v.transform=r.transform;v.content=r.content;v.eraseMasks=r.erase_masks;v.placement=r.placement;v.properties=r.properties;return v;}
}
int main(int argc,char** argv){json out{{"schema","g5-ur0b-fixture-oracle-v1"},{"method","offline SnapshotCodec and uncached canonical exact geometry"}};
 try{
  if(argc<2)throw std::runtime_error("usage: snapshot [literal-fixture actions initial-state]");
  auto snapshot=decode(argv[1],out);if(!snapshot){out["status"]="INVALID_SNAPSHOT";std::cout<<out.dump(2)<<'\n';return 2;}
  out["document_revision"]=std::to_string(snapshot->document_revision);out["object_count"]=snapshot->objects.size();out["objects"]=json::array();
  bool bodies=true;const semantic::CompactStrokeRecord* original=nullptr;
  for(const auto& r:snapshot->objects){
   const auto* compact=std::get_if<semantic::CompactStrokeContent>(&r.content);
   json item{{"id",hex(r.id)},{"kind",static_cast<unsigned>(r.kind)},{"kind_version",r.kind_version},{"transform",{r.transform.a,r.transform.b,r.transform.c,r.transform.d,r.transform.tx,r.transform.ty}},{"mask_count",r.erase_masks.size()}};
   if(compact){const auto& s=compact->stroke;if(!original)original=&s;
    bodies=bodies&&(s==*original);
    const auto& c=s.config;
    item["seed"]=std::to_string(s.seed);item["knots"]=s.knots.size();
    item["config"]={{"version",c.version},{"algorithmVersion",c.algorithmVersion},{"signalVersion",c.signalVersion},{"materialVersion",c.materialVersion},{"family",static_cast<unsigned>(c.family)},{"roundMode",static_cast<unsigned>(c.roundMode)},{"pressureSource",static_cast<unsigned>(c.pressureSource)},{"pressureModel",static_cast<unsigned>(c.pressureModel)},{"size",c.size},{"opacity",c.opacity},{"color",c.color},{"thinning",c.thinning},{"smoothing",c.smoothing},{"streamline",c.streamline},{"startCap",c.startCap},{"endCap",c.endCap},{"startTaper",c.startTaper},{"endTaper",c.endTaper},{"easing",static_cast<unsigned>(c.easing)},{"markerAngle",c.markerAngle},{"markerFlatness",c.markerFlatness},{"density",c.density},{"textureScale",c.textureScale},{"deposition",c.deposition},{"wetEdge",c.wetEdge},{"laserFadeMs",c.laserFadeMs},{"laserTailLength",c.laserTailLength},{"materialResourceId",c.materialResourceId},{"materialResourceSha256",c.materialResourceSha256},{"materialSamplingVersion",c.materialSamplingVersion}};
   }else bodies=false;
   out["objects"].push_back(std::move(item));
  }
  out["copy_bodies_equal"]=bodies;
  if(argc>=5&&original){
   const auto fixture=readJson(argv[2]),actions=readJson(argv[3]),state=readJson(argv[4]);
   auto loaded=ink::BrushPackageCatalog{}.loadDefault("round-handdrawn",4);
   if(!loaded)throw std::runtime_error("pinned catalog unavailable");
   // Use the immutable actual snapshot config: replay does not replace or
   // round an authored config merely to match a catalog presentation default.
   loaded.package.compactConfig=original->config;
   ink::BrushSession replay{1,ink::resolveBrushState(loaded.package,original->seed)};
   if(!replay.begin())throw std::runtime_error("replay begin");
   ink::BrushPreviewDelta preview;std::uint64_t count=0;
   for(const auto& s:fixture["samples"]){
    ink::BrushSample point{double(float(s[0].get<double>()/1000)),double(float(s[1].get<double>()/1000)),.5,false,++count,std::stoull(s[2].get<std::string>()),false,s[4]=="up"};
    if(replay.append(std::span(&point,1),{},preview)!=ink::BrushSessionError::kNone)throw std::runtime_error("replay append");
   }
   ink::BrushCommitIntent sealed;if(replay.seal(sealed)!=ink::BrushSessionError::kNone)throw std::runtime_error("replay seal");
   out["input_confirmed_samples"]=count;out["replay_knots"]=sealed.knots.size();out["replay_matches_snapshot"]=sealed.knots==original->knots;
   double maxPosition=0;std::size_t pressureDifferences=0;json firstDifferences=json::array();
   for(std::size_t i=0;i<std::min(sealed.knots.size(),original->knots.size());++i){const auto& a=sealed.knots[i];const auto& b=original->knots[i];
    maxPosition=std::max({maxPosition,std::abs(a.x-b.x),std::abs(a.y-b.y)});pressureDifferences+=a.pressure!=b.pressure;
    if(a!=b&&firstDifferences.size()<5)firstDifferences.push_back({{"index",i},{"replay",{a.x,a.y,double(a.pressure)}},{"snapshot",{b.x,b.y,double(b.pressure)}}});
   }
   out["replay_diagnostics"]={{"max_position_delta",maxPosition},{"pressure_differences",pressureDifferences},{"first_differences",firstDifferences}};
   if(argc>5&&std::string(argv[5])=="replay-only"){out["status"]="DIAGNOSTIC_ONLY";std::cout<<out.dump(2)<<'\n';return 0;}
   const auto camera=state["state"]["camera"];const double scale=camera["scale"],tx=camera["x"],ty=camera["y"];
   std::vector<RuntimeSceneRecord> records;for(const auto& r:snapshot->objects)records.push_back(record(r));
   const auto selected=state["selection"]["primary"].get<std::string>();
   json stages=json::array();
   for(const auto& interaction:{"E0","E1"}){
    std::vector<foundation::WorldPoint> trace;
    for(const auto& e:actions["plans"]["masked_drag"]["events"])
     if(e["interaction_id"]==interaction&&e["kind"]=="pointer")trace.push_back({float((e["x_milli"].get<double>()/1000-tx)/scale),float((e["y_milli"].get<double>()/1000-ty)/scale)});
    json targets=json::array();
    for(auto& r:records){const auto mask=interaction::partialEraseGeometry(trace,r.transform,16);
     if(!mask)throw std::runtime_error("offline mask construction");
     const auto hit=render::intersectEraseGeometry(r,*mask);
     if(hit==render::SelectionGeometryHit::kInvalid||hit==render::SelectionGeometryHit::kUnsupported)throw std::runtime_error("uncached exact erase oracle invalid");
     if(hit==render::SelectionGeometryHit::kHit){targets.push_back(hex(r.objectId));r.eraseMasks.push_back({foundation::ObjectId::fromUint64(stages.size()+1),*mask});}
    }
    stages.push_back({{"interaction",interaction},{"exact_targets",targets}});
   }
   out["erase_exact_queries"]=stages;
   const float x=float((400-tx)/scale),y=float((120-ty)/scale),epsilon=.0005F;
   const foundation::WorldPoint region[]{{x-epsilon,y-epsilon},{x+epsilon,y-epsilon},{x+epsilon,y+epsilon},{x-epsilon,y+epsilon}};
   json hits=json::array();bool selectedHit=false;
   for(const auto& r:records){const auto h=render::intersectVisibleSelectionGeometry(r,region);
    if(h==render::SelectionGeometryHit::kInvalid||h==render::SelectionGeometryHit::kUnsupported)throw std::runtime_error("fixed point oracle invalid");
    if(h==render::SelectionGeometryHit::kHit){hits.push_back(hex(r.objectId));selectedHit|=hex(r.objectId)==selected;}
   }
   out["fixed_drag"]={{"logical_point",{400,120}},{"world_point",{x,y}},{"selected",selected},{"selected_visible_body_hit_after_E0_E1",selectedHit},{"exact_hits",hits},{"adaptive_search",false}};
   out["status"]=bodies&&sealed.knots==original->knots&&selectedHit&&count==7200&&snapshot->objects.size()==16?"QUALIFIED":"TASK_PACKAGE_DEFECT";
  }else out["status"]="DECODED";
  std::cout<<out.dump(2)<<'\n';return out["status"]=="TASK_PACKAGE_DEFECT"?3:0;
 }catch(const std::exception& error){out["status"]="ORACLE_ERROR";out["error"]=error.what();std::cout<<out.dump(2)<<'\n';return 2;}
}
