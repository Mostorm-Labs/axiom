// Own browser/process only. Run under bounded_worker.py; the parent remains
// responsive when a synchronous WASM call wedges this page.
import {chromium} from '../../../node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {calibrate} from './fixture_plan.mjs';
const here=path.dirname(fileURLToPath(import.meta.url)),repo=path.resolve(here,'../../../..');
const [sdkArg,outArg,mode='fixture',branch='masked_drag',toggle='ON']=process.argv.slice(2),sdkRoot=path.resolve(sdkArg),out=path.resolve(outArg);
await fs.mkdir(out,{recursive:true});
const hash=b=>createHash('sha256').update(b).digest('hex');
const inputs=JSON.parse(await fs.readFile(path.join(repo,'docs/planning/g5-unified-render/ur0a/fixtures/continuous-30s-v1.json')));
const actions=JSON.parse(await fs.readFile(path.join(repo,'docs/planning/g5-unified-render/ur0a/fixtures/immediate-actions-v1.json')));
const stage=object=>console.log(JSON.stringify(object));
const write=(name,data)=>fs.writeFile(path.join(out,name),JSON.stringify(data,null,2)+'\n');
let phaseTimer;const phases=[];
const arm=(phase,limit_ms)=>{clearTimeout(phaseTimer);phases.push({phase,limit_ms,node_monotonic_ns:String(process.hrtime.bigint())});phaseTimer=setTimeout(()=>{stage({stage:'phase-timeout',phase,limit_ms});process.exit(124);},limit_ms);};
arm('setup',mode==='realtime'?40000:45000);
async function artifactHashes(){const files={};for(const n of (await fs.readdir(sdkRoot,{recursive:true})).sort()){const p=path.join(sdkRoot,n);if((await fs.stat(p)).isFile())files[n]=hash(await fs.readFile(p));}return files;}
const source=()=>JSON.parse(execFileSync('python3.12',[path.join(here,'source_identity.py'),repo],{encoding:'utf8',maxBuffer:64*1024*1024}));
let browser,server;const result={schema:'g5-ur0b-worker-v1',mode,branch,toggle,errors:[],status:'STARTED',artifacts_before:await artifactHashes(),source_before:source()};
await write('run-inputs.json',{...result,fixture_sha256:hash(await fs.readFile(path.join(repo,'docs/planning/g5-unified-render/ur0a/fixtures/continuous-30s-v1.json'))),actions_sha256:hash(await fs.readFile(path.join(repo,'docs/planning/g5-unified-render/ur0a/fixtures/immediate-actions-v1.json')))});
try{
 server=http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://127.0.0.1'),name=decodeURIComponent(url.pathname);let file;
  if(name==='/probe.html')file=path.join(here,'consumer.html');else if(name.startsWith('/ur0/'))file=path.resolve(here,name.slice(5));else file=path.resolve(sdkRoot,'.'+name);
  if(!file.startsWith(here+path.sep)&&!file.startsWith(sdkRoot+path.sep))throw Error('path escape');
  res.setHeader('Content-Type',name.endsWith('.mjs')?'text/javascript':name.endsWith('.html')?'text/html':name.endsWith('.wasm')?'application/wasm':'application/octet-stream');
  if(name==='/internal/axiom.mjs'&&toggle!=='NORMAL'){
   // Only this isolated verification server wraps the generated private
   // factory. The public root wrapper/types and business calls remain intact.
   const shim=`import factory from '/internal/ur0-original.mjs';export default async function(options){const m=await factory(options);const read=()=>new TextDecoder().decode(m.HEAPU8.slice(m._axiom_g5_trace_bytes(),m._axiom_g5_trace_bytes()+m._axiom_g5_trace_size()));const control=(op,v=0)=>{const r=m._axiom_g5_trace_control(op,v);if(r!==0)throw Error('private control '+op+':'+r);};globalThis.__ur0diag=Object.freeze({control,clock(){control(3);return JSON.parse(read());},drain(){control(4);return JSON.parse(read());}});return m;}`;
   result.loader_sha256=hash(shim);res.end(shim);
  }else res.end(await fs.readFile(name==='/internal/ur0-original.mjs'?path.join(sdkRoot,'internal/axiom.mjs'):file));
 }catch(error){res.statusCode=404;res.end(String(error));}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const executable='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
 browser=await chromium.launch({executablePath:executable,headless:true});
 result.browser={version:browser.version(),executable,flags:'Playwright defaults; no disable-gpu; headless true'};
 const page=await browser.newPage({viewport:{width:900,height:650},deviceScaleFactor:2});
 page.on('pageerror',error=>result.errors.push(String(error)));
 page.on('console',message=>{if(message.text().startsWith('UR0_STAGE '))stage(JSON.parse(message.text().slice(10)));});
 await page.addInitScript(()=>{let word=0x12345678;crypto.getRandomValues=a=>{const b=new Uint8Array(a.buffer,a.byteOffset,a.byteLength);for(let i=0;i<b.length;++i){word^=word<<13;word^=word>>>17;word^=word<<5;b[i]=word&255;}return a;};});
 await page.goto('http://127.0.0.1:'+server.address().port+'/probe.html');
 await page.waitForFunction(()=>!!window.ur0);stage({stage:'initializing'});
 result.init=await page.evaluate(()=>ur0.init());await write('init.json',result.init);stage({stage:'setup'});
 if(mode==='realtime'){arm('measurement',35000);result.measurement=await page.evaluate(({fixture,hz,on})=>ur0.realtime({fixture,hz,on}),{fixture:inputs,hz:Number(branch),on:toggle==='ON'});arm('cleanup',15000);}
 else{
  result.setup=mode==='legacy'?await page.evaluate(kind=>ur0.setupLegacy(kind),branch):await page.evaluate(fixture=>ur0.setup({fixture}),inputs);await write('setup.json',result.setup);
  const capture=async label=>{const row=await page.evaluate(label=>ur0.checkpoint(label),label);const bytes=Buffer.from(row.snapshot.bytes);await fs.writeFile(path.join(out,label+'.axsnap'),bytes);row.snapshot={...row.snapshot,bytes:undefined,path:label+'.axsnap',byte_length:bytes.length,sha256:hash(bytes)};await write(label+'.json',row);return row;};
  result.initial=await capture('initial');
  if(mode!=='setup'){
   const prepared=mode==='legacy'?{measurement_schedule:'LEGACY_CLOSED_LOOP',kind:branch,source_references:['verification/runners/g5/drag_copies.mjs','verification/runners/g5/cumulative_erase.mjs'],fixed_rounds:branch==='legacy16_erase'?10:1}:await page.evaluate(events=>ur0.prepareMeasurement(events),actions.plans[branch].events);await write('prepared-plan.json',prepared);
   stage({stage:'measurement',branch});
   const limit=mode==='main'||mode==='legacy'?120000:30000;arm('measurement',limit);
   result.measurement=mode==='legacy'?await page.evaluate(({kind,on,start})=>ur0.measureLegacy({kind,on,start}),{kind:branch,on:toggle==='ON',start:result.setup.legacy_drag_start}):await page.evaluate(({prepared,on,limit})=>ur0.measure({prepared,on,deadlineMs:limit}),{prepared,on:toggle==='ON',limit});
   arm('cleanup',15000);
   await write('measurement.json',result.measurement);result.final=await capture('final');
  }else arm('cleanup',15000);
 }
 if(result.measurement?.clock_before)result.calibration=calibrate(result.measurement.clock_before,result.measurement.clock_after);
 if(toggle!=='NORMAL'){
  const pages=[];for(let i=0;i<4096;++i){const p=await page.evaluate(()=>ur0.drain());pages.push(p);if(p.finished)break;if(i===4095)throw Error('bounded drain exhausted');}
  result.trace={loss:pages.at(-1).loss,pending_gpu:pages.at(-1).pending_gpu,records:pages.reduce((n,p)=>n+p.records.length,0)};
  await fs.writeFile(path.join(out,'raw-trace.jsonl'),pages.flatMap(p=>p.records).map(r=>JSON.stringify(r)+'\n').join(''));await write('trace-pages.json',pages.map(({records,...p})=>({...p,count:records.length})));
 }
 result.close=await page.evaluate(()=>ur0.close());if(!result.close.closed)throw Error('Runtime did not close');
 if(toggle!=='NORMAL'){
  const cleanup=[];for(let i=0;i<4096;++i){const p=await page.evaluate(()=>ur0.drain());cleanup.push(p);if(p.finished)break;if(i===4095)throw Error('bounded cleanup drain exhausted');}
  await fs.writeFile(path.join(out,'raw-cleanup.jsonl'),cleanup.flatMap(p=>p.records).map(r=>JSON.stringify(r)+'\n').join(''));
  result.cleanup_trace={loss:cleanup.at(-1).loss,pending_gpu:cleanup.at(-1).pending_gpu,records:cleanup.reduce((n,p)=>n+p.records.length,0),scope:'after measurement, during Runtime close; never a primary completion'};
 }
 result.status='OBSERVED';
}catch(error){result.status='BLOCKED_EVIDENCE';result.error=String(error.stack??error);process.exitCode=1;}
finally{
 if(phases.at(-1)?.phase!=='cleanup')arm('cleanup',15000);
 if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));
 result.artifacts_after=await artifactHashes();result.artifacts_stable=JSON.stringify(result.artifacts_before)===JSON.stringify(result.artifacts_after);
 result.source_after=source();result.source_stable=result.source_before.source_tree_sha256===result.source_after.source_tree_sha256;
 if(!result.artifacts_stable||!result.source_stable||result.errors.length){result.status='BLOCKED_EVIDENCE';process.exitCode=1;}
 result.phase_guards=phases;await write('worker-result.json',result);stage({stage:'complete',status:result.status,error:result.error,trace:result.trace});clearTimeout(phaseTimer);
}
