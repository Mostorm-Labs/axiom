import test from 'node:test';import assert from 'node:assert/strict';
let api={};try{api=await import('../runners/g5/ur0/decode_trace.mjs');}catch(e){if(e.code!=='ERR_MODULE_NOT_FOUND')throw e;}
const raw=()=>{
 const r=(kind,tag,values,job='10')=>({kind,tag,values:values.map(String),job,basis:job,attempt:job,event:'1',purpose:2,route:1,at_ns:'100',seq:'1'});
 return [
  r(5,1,[11,1,2,0,0,4,7,1]),
  r(6,27,[0,0,1,0,8,9,4,6]),
  r(7,9,[9,9,44]),
  r(5,26,[1,23,9,44,4,2,3,8,67108864,201326592],'20'),
  r(11,19,[1,23,9,44,2,3,0],'20'),
  r(5,26,[10,11,1,2,0,0,4,6,7,44,4]),
  r(11,29,[10,1,23,9,9,2,3]),
  r(12,29,[1,10,11,1,2,1,23,9,9,2,3]),
 ];
};
test('decodes actual observed commit Scene submit and completion fields',()=>{
 assert.equal(typeof api.decodeTrace,'function','raw trace decoder unavailable');
 const d=api.decodeTrace(raw(),{critical:0,statistical:0});assert.equal(d.errors.length,0);assert.equal(d.qualified_completions.length,1);
 assert.equal(d.qualified_completions[0].work,'10');assert.equal(d.qualified_completions[0].resource,'7');assert.equal(d.frames[0].gpu_resource_epoch,'8');
});
test('foreign completion or mismatched Scene cannot be repaired by copying expected fields',()=>{
 assert.equal(typeof api.decodeTrace,'function','raw trace decoder unavailable');
 const foreign=raw();foreign.at(-1).values[3]='99';assert.ok(api.decodeTrace(foreign,{critical:0,statistical:0}).errors.length);
 const stale=raw();stale[2].values[1]='8';assert.ok(api.decodeTrace(stale,{critical:0,statistical:0}).errors.length);
});
test('Scene intent publication can precede the callsite observation of its returned commit record',()=>{
 const rows=raw();[rows[1],rows[2]]=[rows[2],rows[1]];rows[1].at_ns='98';
 const d=api.decodeTrace(rows,{critical:0,statistical:0});assert.equal(d.errors.length,0);assert.equal(d.qualified_completions.length,1);
 assert.equal(d.scenes[0].commit_observed_after_publication,true);
});
test('scope exclusive time and GPU callback ordering preserve raw facts',()=>{
 assert.equal(typeof api.decodeTrace,'function','raw trace decoder unavailable');
 const base={seq:'1',job:'1',basis:'1',attempt:'1',event:'0',purpose:2,route:1};
 const rows=[{...base,kind:2,tag:10,values:['1','2','0'],at_ns:'0'},{...base,kind:2,tag:18,values:['2','0','1'],at_ns:'2'},{...base,kind:3,tag:18,values:['2'],at_ns:'7'},{...base,kind:3,tag:10,values:['1'],at_ns:'10'},
 {...base,kind:14,tag:0,values:['5','7','0','0'],at_ns:'11'},{...base,kind:13,tag:0,values:['5','7','3','1'],at_ns:'12'},{...base,kind:15,tag:0,values:['5','3'],at_ns:'14'}];
 const d=api.decodeTrace(rows,{critical:0,statistical:0});assert.equal(d.spans.find(s=>s.id==='1').exclusive_ns,'5');assert.equal(d.gpu[0].callback_before_submit_return,true);
 assert.equal(d.gpu[0].pure_gpu_duration_ns,null);
});
