// Numeric record decoder. Every join cites actual record sequence numbers.
// Unknown/absent fields stay absent; no placeholder zero or expected-stamp fill.
const hexWord=value=>{let n=BigInt(value),s='';for(let i=0;i<8;++i){s+=(n&255n).toString(16).padStart(2,'0');n>>=8n;}return s;};
const id=(a,b)=>hexWord(a)+hexWord(b);
const routeNames=['NONE','CAN-PREP-V4','CAN-DIRECT','EDIT-PLAIN','EDIT-MASK-ISOLATED','EDIT-MASK-DIRECT','ERASE-LAYERS','ERASE-RESIDENT','ERASE-MISS','NAV-COARSE-GPU','NAV-COARSE-CPU','NAV-UNPREPARED','NAV-RETAINED','PREVIEW-PREFIX','PREVIEW-TAIL','CREATION-CANONICAL','CREATION-TRANSIENT','RECORDING'];
const targetNames=['NONE','CPU','GPU','RECORDING'];
export function decodeTrace(records,loss){
 const out={schema:'g5-ur0b-decoded-v1',errors:[],missing:[],commits:[],scenes:[],frames:[],qualified_completions:[],unqualified_completions:[],decisions:[],leaves:[],spans:[],gpu:[],counters:[],loss};
 const fail=(reason,r)=>out.errors.push({reason,seq:r?.seq??null});
 if(loss?.critical)fail('critical record loss');
 const begins=new Map(),groups=new Map(),owners=[],renderFrames=[],providerSubmits=[],workBasis=new Map(),work=new Map(),commits=[],scenes=[];
 for(const r of records){const v=r.values;
  if(r.kind===5&&r.tag===1&&v.length===8)owners.push({raw:r,runtime:v[0],lifetime:v[1],attachment:v[2],document:id(v[3],v[4]),documentEpoch:v[5],resource:v[6],view:v[7]});
  if(r.kind===6&&r.tag===27){
   const owner=owners.findLast(o=>o.raw.job===r.job)??owners.at(-1);
   if(!owner){out.missing.push({reason:'commit owner unavailable',seq:r.seq});continue;}
   const c={runtime:owner.runtime,lifetime:owner.lifetime,attachment:owner.attachment,document:id(v[0],v[1]),operation:id(v[2],v[3]),beforeGeneration:v[4],afterGeneration:v[5],documentEpoch:v[6],commitRevision:v[7],resource:owner.resource,at_ns:r.at_ns,event:r.event,job:r.job,provenance:[owner.raw.seq,r.seq]};
   if(c.document!==owner.document)fail('foreign commit document',r);commits.push(c);
  }
 }
 for(const r of records){
  const v=r.values;
  if(!Array.isArray(v)||v.some(n=>typeof n!=='string'||!/^[0-9]+$/.test(n))){fail('invalid lossless raw values',r);continue;}
  if(r.kind===2)begins.set(v[0],{id:v[0],parent:v[2]??null,tag:r.tag,job:r.job,start_ns:v[3]??r.at_ns,end_ns:null,inclusive_ns:null,exclusive_ns:null,seq:r.seq});
  if(r.kind===3){const s=begins.get(v[0]);if(!s)out.missing.push({reason:'span begin missing',seq:r.seq});else{s.end_ns=v[1]??r.at_ns;s.inclusive_ns=String(BigInt(s.end_ns)-BigInt(s.start_ns));s.exclusive_ns=v[2]??null;}}
  if(r.kind===10&&[17,22].includes(r.tag)&&v[0]==='9')begins.set(v[1],{id:v[1],parent:v[2],tag:r.tag,job:r.job,start_ns:null,end_ns:null,inclusive_ns:v[4],exclusive_ns:v[5],invocations:v[3],clock_domain:'wasm_local_duration',seq:r.seq});
  if(r.kind===5&&r.tag===1&&v.length===8)owners.push({raw:r,runtime:v[0],lifetime:v[1],attachment:v[2],document:id(v[3],v[4]),documentEpoch:v[5],resource:v[6],view:v[7]});
  if(r.kind===7&&r.tag===9){
   const commit=commits.findLast(c=>c.afterGeneration===v[0]);
   if(v[0]!==v[1])fail('published Scene generation disagrees with commit',r);
   if(!commit){out.missing.push({reason:'Scene commit outside observed window',seq:r.seq});continue;}
   scenes.push({...commit,semanticGeneration:v[0],sceneGeneration:v[1],sceneRevision:v[2],at_ns:r.at_ns,commit_observed_after_publication:BigInt(commit.at_ns)>BigInt(r.at_ns),provenance:[...commit.provenance,r.seq]});
  }
  if(r.kind===5&&r.tag===26&&v.length===10)renderFrames.push({view:v[0],frame:v[1],sceneGeneration:v[2],sceneRevision:v[3],camera:v[4],surface:v[5],metrics:v[6],gpu_resource_epoch:v[7],job:r.job,at_ns:r.at_ns,seq:r.seq});
  if(r.kind===11&&r.tag===19)providerSubmits.push({view:v[0],frame:v[1],sceneGeneration:v[2],sceneRevision:v[3],surface:v[4],metrics:v[5],code:v[6],job:r.job,at_ns:r.at_ns,seq:r.seq});
  if(r.kind===5&&r.tag===26&&v.length===11)workBasis.set(v[0],{runtime:v[1],lifetime:v[2],attachment:v[3],document:id(v[4],v[5]),documentEpoch:v[6],commitRevision:v[7],resource:v[8],sceneRevision:v[9],camera:v[10],seq:r.seq});
  if(r.kind===11&&r.tag===29){
   const owner=workBasis.get(v[0]);if(!owner){fail('work capture has no owner basis',r);continue;}
   const match=s=>s.view===v[1]&&s.frame===v[2]&&s.sceneGeneration===v[4]&&s.surface===v[5]&&s.metrics===v[6];
   const submitted=providerSubmits.findLast(s=>match(s)&&s.code==='0'),draw=renderFrames.findLast(match);
   if(!submitted||!draw){out.missing.push({reason:'work capture has no new observed provider submit',seq:r.seq,work:v[0]});continue;}
   if(owner.sceneRevision!==draw.sceneRevision||owner.camera!==draw.camera)fail('work capture and actual drawn basis differ',r);
   const scene=scenes.findLast(s=>s.sceneGeneration===v[4]&&s.semanticGeneration===v[3]&&s.sceneRevision===draw.sceneRevision);
   if(!scene){out.missing.push({reason:'frame Scene publication outside observed window',seq:r.seq,work:v[0]});}
   else if(owner.commitRevision!==scene.commitRevision||owner.documentEpoch!==scene.documentEpoch||owner.document!==scene.document)fail('frame commit and published Scene differ',r);
   const f={...owner,work:v[0],view:v[1],frame:v[2],semanticGeneration:v[3],sceneGeneration:v[4],surface:v[5],metrics:v[6],operation:scene?.operation??null,scene_qualified:!!scene,at_ns:submitted.at_ns,job:draw.job,gpu_resource_epoch:draw.gpu_resource_epoch,provenance:[owner.seq,r.seq,submitted.seq,draw.seq,...(scene?.provenance??[])]};
   out.frames.push(f);work.set(v[0],f);
  }
  if(r.kind===12&&r.tag===29&&v[0]!=='0'){
   const f=work.get(v[1]),observed={runtime:v[2],lifetime:v[3],attachment:v[4],view:v[5],frame:v[6],semanticGeneration:v[7],sceneGeneration:v[8],surface:v[9],metrics:v[10]};
   if(v[0]==='1'){
    if(!f){out.missing.push({reason:'accepted completion outside observed work',seq:r.seq});continue;}
    if(Object.keys(observed).some(k=>f[k]!==observed[k])){fail('foreign/stale accepted completion',r);continue;}
    const c={...f,...observed,at_ns:r.at_ns,provenance:[...f.provenance,r.seq],qualification:f.scene_qualified?'QUALIFIED':'MISSING_SETUP_SCENE_OBSERVATION'};
    (f.scene_qualified?out.qualified_completions:out.unqualified_completions).push(c);
   }else out.unqualified_completions.push({...observed,work:v[1],at_ns:r.at_ns,qualification:'REJECTED'});
  }
  if(r.kind===8){out.decisions.push({id:v[0],route:routeNames[Number(v[1])]??'UNKNOWN',job:r.job,basis:r.basis,actual_target:targetNames[Number(v[2])]??'UNKNOWN',requested_gpu:v[3]==='1',origin:'CURRENT_BRANCH',seq:r.seq});}
  if(r.kind===9){
   const decision=out.decisions.findLast(d=>d.id===v[0]);const leaf={decision:v[0],route:routeNames[Number(v[1])]??'UNKNOWN',target_label:v[2],target:targetNames[Number(v[3])]??'UNKNOWN',width:v[4],height:v[5],format:v[6],job:r.job,basis:r.basis,at_ns:r.at_ns,seq:r.seq,target_identity_scope:'equivalent actual target uses within job; address may be reused, never a persistent/canonical ID'};
   if(!decision||decision.job!==leaf.job||decision.basis!==leaf.basis||decision.route!==leaf.route)fail('foreign decision/leaf basis',r);
   if(leaf.route==='UNKNOWN'||leaf.route==='NONE')fail('unknown/unbound observed route',r);out.leaves.push(leaf);
  }
  if(r.kind===10){out.counters.push(r);if(r.tag===24&&v[0]==='9'){
   const leaf=out.leaves.findLast(l=>l.decision===v[1]);if(!leaf||leaf.job!==r.job)fail('target-use aggregate has foreign job',r);else{leaf.actual_uses=v[9];leaf.last_use_ns=v[10];}
  }}
  if([13,14,15].includes(r.kind)){
   const group=groups.get(v[0])??{group:v[0],job:r.job,basis:r.basis,submit_ns:null,completed_ns:null,retired_ns:null,pure_gpu_duration_ns:null,provenance:[]};groups.set(v[0],group);group.provenance.push(r.seq);
   if(r.kind===13){group.context_label=v[1];group.epoch=v[2];group.submit_ns=r.at_ns;group.submit_accepted=v[3]==='1';}
   if(r.kind===14){group.completed_ns=r.at_ns;group.abandoned=v[2]==='1';group.physical_lost=v[3]==='1';}
   if(r.kind===15)group.retired_ns=r.at_ns;
  }
 }
 out.commits=commits;out.scenes=scenes;
 for(const s of begins.values()){
  if(s.inclusive_ns!==null){if(s.exclusive_ns===null){const child=[...begins.values()].filter(c=>c.parent===s.id&&c.inclusive_ns!==null).reduce((n,c)=>n+BigInt(c.inclusive_ns),0n);s.exclusive_ns=String(BigInt(s.inclusive_ns)-child);}if(BigInt(s.exclusive_ns)<0n)fail('invalid nested stage durations');}
  else s.status='RIGHT_CENSORED';out.spans.push(s);
 }
 for(const g of groups.values()){g.callback_before_submit_return=g.submit_ns!==null&&g.completed_ns!==null&&BigInt(g.completed_ns)<BigInt(g.submit_ns);g.status=g.abandoned||g.physical_lost?'LOST':g.retired_ns?'RETIRED':g.completed_ns?'COMPLETED_WAITING_RETIREMENT':g.submit_ns?'PENDING':'MISSING_SUBMIT';out.gpu.push(g);}
 return out;
}
