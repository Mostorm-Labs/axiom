#include "canvas/foundation/internal/g5_observation.hpp"
#include "canvas/semantic/document_id.hpp"
#include "canvas/semantic/operation_id.hpp"
#include <nlohmann/json.hpp>
#include <cstdlib>
#include <iostream>
using namespace canvas::foundation::internal::g5;
void need(bool yes){if(!yes){std::cerr<<"FAIL: scoped identity changed\n";std::exit(1);}}
int main(){
 canvas::foundation::ObjectId raw{};raw.bytes[0]=0xab;raw.bytes[15]=0xef;
 need(word(canvas::semantic::DocumentId{raw},0)==171);
 need(word(canvas::semantic::OperationId{raw},1)==17221764975064776704ULL);
 need(control(2,1)==0&&control(1,0)==0);
 std::uint64_t parent=0;
 {
  Scope outer{Tag::canonical,Purpose::canonical};RouteScope route{Route::canonical_prepared};parent=context().job;
  need(parent!=0);need(control(3,0)!=0);
  {Scope inner{Tag::exact_prepare,Purpose::exact_query};need(context().job!=parent);emit(Kind::Basis,Tag::canonical_basis,{18446744073709551615ULL,9},true);}
  need(context().job==parent&&context().route==Route::canonical_prepared);
  observeTarget(10,2,256,256,4,true);
 }
 need(context().job==0);need(control(4,0)==0);
 auto data=nlohmann::json::parse(bytes(),bytes()+size());unsigned starts=0,ends=0,leaves=0;
 for(const auto& r:data["records"]){starts+=r["kind"]==static_cast<unsigned>(Kind::Begin);ends+=r["kind"]==static_cast<unsigned>(Kind::End);if(r["kind"]==static_cast<unsigned>(Kind::Leaf)){++leaves;need(r["job"]==std::to_string(parent));need(r["values"][3]=="2");}}
 need(starts==2&&ends==2&&leaves==1);std::cout<<"strong Id128/scoped job/leaf/early-reentrancy PASS\n";
}
